package com.github.ljtfreitas.julian.samples.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSamplesApplicationTests {

	@Test
	void contextLoads() {
	}

}
